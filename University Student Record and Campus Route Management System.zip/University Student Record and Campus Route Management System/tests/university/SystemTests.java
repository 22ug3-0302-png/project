package university;

import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;

/** Dependency-free behavioral tests. Failures throw even without Java's -ea flag. */
public final class SystemTests {
    private static int checks;

    private SystemTests() { }

    public static void main(String[] args) {
        testValidation();
        testLinkedStructures();
        testHashCollisionsAndResize();
        testTreeDeletion();
        testRegistryConsistency();
        testCampusGraph();
        testConsoleWorkflow();
        testEndOfInput();
        System.out.println("PASS: " + checks + " checks across 8 test groups.");
    }

    private static Student student(String id) { return new Student(id, "Student " + id, "Computing", 75); }

    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) { throw new AssertionError(message); }
    }

    private static void expect(Class<? extends Throwable> type, Runnable operation) {
        checks++;
        try { operation.run(); }
        catch (Throwable exception) {
            if (type.isInstance(exception)) { return; }
            throw new AssertionError("Expected " + type.getSimpleName() + ", got " + exception, exception);
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }

    private static void testValidation() {
        check(student(" s_01 ").getId().equals("S_01"), "IDs normalize");
        for (String id : Arrays.asList(null, "", " ", "S 01", "S/01")) {
            expect(IllegalArgumentException.class, () -> student(id));
        }
        for (double marks : new double[] {-1, 100.01, Double.NaN, Double.POSITIVE_INFINITY,
                Double.NEGATIVE_INFINITY}) {
            expect(IllegalArgumentException.class, () -> new Student("S1", "Name", "Programme", marks));
        }
        check(new Student("S1", " Name ", " Programme ", 0).getMarks() == 0, "Zero marks accepted");
        check(new Student("S1", "Name", "Programme", 100).getMarks() == 100, "100 marks accepted");
        expect(IllegalArgumentException.class, () -> new Student("S1", " ", "Programme", 50));
        expect(IllegalArgumentException.class, () -> new Student("S1", "Name", null, 50));
    }

    private static void testLinkedStructures() {
        StudentLinkedList list = new StudentLinkedList();
        check(list.remove("S1") == null, "Empty list removal");
        list.add(student("S1")); list.add(student("S2")); list.add(student("S3"));
        check(list.remove("s1").getId().equals("S1"), "Remove list head");
        check(list.remove("S3").getId().equals("S3"), "Remove list tail");
        list.add(student("S4"));
        List<String> ids = new ArrayList<>();
        for (Student item : list) { ids.add(item.getId()); }
        check(ids.equals(Arrays.asList("S2", "S4")), "Tail append after removal");
        list.remove("S2"); list.remove("S4"); list.add(student("S5"));
        check(list.size() == 1 && list.iterator().next().getId().equals("S5"), "Reuse emptied list");

        LinkedStack<String> stack = new LinkedStack<>();
        expect(NoSuchElementException.class, stack::pop);
        stack.push("old"); stack.push("new");
        List<String> history = new ArrayList<>();
        for (String item : stack) { history.add(item); }
        check(history.equals(Arrays.asList("new", "old")) && stack.size() == 2, "History is nondestructive LIFO");
        check(stack.peek().equals("new") && stack.pop().equals("new"), "Stack peek and pop");
        check(stack.pop().equals("old") && stack.isEmpty(), "Stack empties");

        LinkedQueue<String> queue = new LinkedQueue<>();
        expect(NoSuchElementException.class, queue::dequeue);
        queue.enqueue("first"); queue.enqueue("second");
        check(queue.peek().equals("first") && queue.size() == 2, "Queue peek");
        check(queue.dequeue().equals("first") && queue.dequeue().equals("second"), "FIFO order");
        check(queue.isEmpty(), "Queue empties");
        queue.enqueue("third");
        check(queue.dequeue().equals("third") && queue.size() == 0, "Reuse emptied queue");
    }

    private static void testHashCollisionsAndResize() {
        StudentHashTable table = new StudentHashTable();
        // A and Q collide in the initial 16 buckets.
        table.put(student("A")); table.put(student("Q"));
        check(table.get("A") != null && table.get("Q") != null, "Collision retains both records");
        table.remove("A");
        check(table.get("A") == null && table.get("Q") != null, "Collision chain removal");
        table.put(student("A")); table.remove("Q");
        check(table.get("A") != null && table.get("Q") == null, "Collision chain remains searchable");
        for (int i = 0; i < 1000; i++) { table.put(student("H" + i)); }
        check(table.size() == 1001, "Size after multiple rehashes");
        for (int i = 0; i < 1000; i++) { check(table.get("h" + i) != null, "Lookup after resize " + i); }
        table.put(new Student("H50", "Updated", "Maths", 91));
        check(table.size() == 1001 && table.get("H50").getMarks() == 91, "Hash replacement");
        for (int i = 0; i < 1000; i++) { check(table.remove("H" + i) != null, "Removal after resize " + i); }
        check(table.size() == 1 && table.get("A") != null, "Remaining record after removals");
    }

    private static void testTreeDeletion() {
        StudentBST tree = new StudentBST();
        for (String id : Arrays.asList("D", "B", "G", "A", "C", "E", "F", "H")) { tree.put(student(id)); }
        check(tree.remove("D"), "Delete root with two children and a deep successor");
        check(tree.find("D") == null && tree.find("F") != null, "Successor child preserved");
        check(tree.remove("G"), "Delete two-child node with immediate successor");
        check(tree.remove("E"), "Delete changed root");
        check(tree.remove("A"), "Delete leaf");
        check(tree.remove("B"), "Delete one-child node");
        check(ids(tree.inOrder()).equals(Arrays.asList("C", "F", "H")), "Sorted tree after deletions");
        check(!tree.remove("Z"), "Missing tree record");
        for (String id : Arrays.asList("C", "F", "H")) { tree.remove(id); }
        check(tree.inOrder().isEmpty(), "Empty tree");
        for (int i = 0; i < 1500; i++) { tree.put(student(String.format("%05d", i))); }
        check(tree.inOrder().size() == 1500, "Skewed tree traversal");
        check(tree.remove("01499") && tree.find("01498") != null, "Skewed tree deletion");
    }

    private static List<String> ids(List<Student> records) {
        List<String> result = new ArrayList<>();
        for (Student record : records) { result.add(record.getId()); }
        return result;
    }

    private static void testRegistryConsistency() {
        StudentRegistry registry = new StudentRegistry();
        Map<String, Student> expected = new LinkedHashMap<>();
        Random random = new Random(2026);
        for (int step = 0; step < 700; step++) {
            String id = "S" + random.nextInt(80);
            int action = random.nextInt(3);
            if (action == 0) {
                Student record = student(id);
                if (expected.containsKey(id)) {
                    expect(IllegalArgumentException.class, () -> registry.add(record));
                } else { registry.add(record); expected.put(id, record); }
            } else if (action == 1) {
                Student replacement = new Student(id, "Updated " + step, "Science", random.nextInt(101));
                if (expected.containsKey(id)) { registry.update(replacement); expected.put(id, replacement); }
                else { expect(IllegalArgumentException.class, () -> registry.update(replacement)); }
            } else {
                if (expected.containsKey(id)) {
                    check(registry.delete(id) == expected.remove(id), "Delete returns expected object");
                } else { expect(IllegalArgumentException.class, () -> registry.delete(id)); }
            }
            check(registry.size() == expected.size(), "Registry count agrees");
            check(registry.insertionOrder().equals(new ArrayList<>(expected.values())), "List preserves record order and updates");
            List<String> sorted = new ArrayList<>(expected.keySet());
            Collections.sort(sorted);
            check(ids(registry.sortedById()).equals(sorted), "BST matches expected IDs");
            for (Student record : expected.values()) {
                check(registry.searchByHash(record.getId()) == record, "Hash matches record");
                check(registry.searchByTree(record.getId()) == record, "BST matches record");
            }
            if (!expected.containsKey(id)) {
                check(registry.searchByHash(id) == null && registry.searchByTree(id) == null, "No stale index entry");
            }
        }
    }

    private static void testCampusGraph() {
        CampusGraph graph = new CampusGraph();
        check(graph.adjacencyList().isEmpty(), "Empty campus");
        expect(IllegalArgumentException.class, () -> graph.addLocation(" "));
        expect(IllegalArgumentException.class, () -> graph.breadthFirstTraversal("Unknown"));
        for (String name : Arrays.asList("Main Gate", "Library", "Lab", "Cafeteria", "Hostel")) { graph.addLocation(name); }
        expect(IllegalArgumentException.class, () -> graph.addLocation(" MAIN   gate "));
        expect(IllegalArgumentException.class, () -> graph.addConnection("Library", "Missing"));
        expect(IllegalArgumentException.class, () -> graph.addConnection("Library", "library"));
        graph.addConnection("main gate", "Library"); graph.addConnection("Main Gate", "Lab");
        graph.addConnection("Library", "Cafeteria"); graph.addConnection("Lab", "Cafeteria");
        expect(IllegalArgumentException.class, () -> graph.addConnection("Library", "Main Gate"));
        check(graph.adjacencyList().get("Library").contains("Main Gate"), "Undirected road");
        check(graph.breadthFirstTraversal("MAIN GATE").equals(Arrays.asList("Main Gate", "Library", "Lab", "Cafeteria")),
                "BFS handles cycle and excludes disconnected vertex");
        check(graph.breadthFirstTraversal("Hostel").equals(Arrays.asList("Hostel")), "Isolated vertex traversal");
        graph.removeConnection("Library", "Main Gate");
        check(!graph.adjacencyList().get("Library").contains("Main Gate")
                && !graph.adjacencyList().get("Main Gate").contains("Library"), "Remove both directions");
        expect(IllegalArgumentException.class, () -> graph.removeConnection("Library", "Main Gate"));
        graph.removeLocation("Cafeteria");
        for (List<String> neighbours : graph.adjacencyList().values()) {
            check(!neighbours.contains("Cafeteria"), "No dangling roads after vertex removal");
        }
        expect(IllegalArgumentException.class, () -> graph.removeLocation("Cafeteria"));
        graph.addLocation("Cafeteria");
        check(graph.adjacencyList().get("Cafeteria").isEmpty(), "Re-added vertex has no old roads");
    }

    private static String runConsole(String... lines) {
        StringWriter output = new StringWriter();
        new ConsoleApp(new StringReader(String.join("\n", lines) + "\n"), new PrintWriter(output)).run();
        return output.toString();
    }

    private static void testConsoleWorkflow() {
        String transcript = runConsole(
                "text", "0", "17", "1.5", "4", "6", "7", "8", "14", "15",
                "1", "bad id", "s2", "", "Nimal", "Computing", "NaN", "Infinity", "-1", "101", "abc", "80.5",
                "1", "S2",
                "1", "S1", "Amali", "Engineering", "100",
                "4", "8", "9", "s2",
                "2", "S2", "Nimal Perera", "", "90",
                "2", "S1", "", "", "",
                "5", "S2", "", "Transcript",
                "5", "S1", "ID card",
                "3", "S2", "9", "S2", "2", "MISSING", "5", "MISSING",
                "6", "6", "6",
                "10", "Main Gate", "10", "Library", "10", "Hostel", "10", "library",
                "12", "Main Gate", "Library", "12", "Library", "Main Gate",
                "12", "Main Gate", "Missing", "12", "Library", "Library",
                "14", "15", "main gate", "15", "Missing",
                "13", "Main Gate", "Library", "13", "Main Gate", "Library",
                "11", "Library", "11", "Library", "7", "16");
        for (String expected : Arrays.asList("Please enter a whole number from 1 to 16.",
                "This field cannot be blank.", "Marks must be a finite number from 0 to 100.",
                "Student ID already exists: S2", "Student updated successfully.",
                "S2 | Nimal Perera | Computing | 90.00", "Student record not found.",
                "No service requests pending.", "No actions recorded yet.",
                "Found using the hash table:", "Campus location already exists:",
                "A connection already exists", "A road must connect two different locations.",
                "Campus location not found:", "No connection exists between these locations.",
                "BFS visit order: Main Gate -> Library", "Visited 2 of 3 locations.",
                "Other locations are unreachable", "Location and all its connections removed",
                "this request retains the original student details.", "Goodbye.")) {
            check(transcript.contains(expected), "Console output: " + expected);
        }
        check(transcript.indexOf("Processing: Request #1") < transcript.indexOf("Processing: Request #2"),
                "Console processes requests in arrival order");
        String history = transcript.substring(transcript.lastIndexOf("Action history (newest first):"));
        check(history.indexOf("Removed campus location") < history.indexOf("Added student:"), "Console history newest first");
        check(!transcript.contains("Exception in thread"), "No uncaught console exceptions");
    }

    private static void testEndOfInput() {
        StringWriter output = new StringWriter();
        new ConsoleApp(new StringReader(""), new PrintWriter(output)).run();
        check(output.toString().contains("Input closed."), "EOF at menu");
        String partial = runConsole("1", "S1", "Name");
        check(partial.contains("Input closed.") && !partial.contains("Student added successfully."), "EOF during add makes no record");
    }
}
