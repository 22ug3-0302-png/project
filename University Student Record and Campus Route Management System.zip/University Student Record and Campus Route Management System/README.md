# University Student Record and Campus Route Management System

A Java console application demonstrating linked lists, stacks, queues, binary search trees, hashing, and graphs. It manages student records, processes student service requests in arrival order, and represents two-way roads between campus locations.

## Requirements and running

- JDK 17 or later, with `java` and `javac` on your PATH.
- No external dependencies, database, build tool, or internet connection required.

From the project folder on Windows (PowerShell or Command Prompt):

```powershell
.\run.bat
```

Or compile and run directly (Windows, Linux, or macOS):

```text
javac -encoding UTF-8 -d out src/university/*.java
java -cp out university.Main
```

The application starts with empty records, requests, history, and campus locations. **All data exists only during the current session and is lost on exit.**

## Menu

| Option | Operation |
| --- | --- |
| 1 | Add a student |
| 2 | Update a student's name, programme, or marks |
| 3 | Delete a student |
| 4 | Display records in linked-list insertion order |
| 5 | Enqueue a student service request |
| 6 | Process the oldest pending service request |
| 7 | Display action history from newest to oldest |
| 8 | Display students in ascending Student ID order using BST in-order traversal |
| 9 | Search for a Student ID using hashing |
| 10 | Add a campus location |
| 11 | Remove a campus location and all its incident roads |
| 12 | Add a two-way campus road |
| 13 | Remove a campus road |
| 14 | Display the campus adjacency list, including isolated locations |
| 15 | Traverse reachable locations using BFS from a chosen location |
| 16 | Exit |

## Data structures and design

| Structure | Implementation | Purpose |
| --- | --- | --- |
| Singly linked list | `StudentLinkedList`: custom nodes, head, tail | Primary record collection; insertion-order display, replacement and deletion |
| Stack | `LinkedStack<T>`: custom linked nodes | Timestamped action history, newest first; also supports iterative BST traversal |
| Queue | `LinkedQueue<T>`: custom front/rear nodes | FIFO student service requests and BFS frontier |
| BST | `StudentBST`: custom left/right child nodes | Student ID search, insertion, replacement, deletion and sorted display |
| Hash table | `StudentHashTable`: custom bucket array and collision chains | Fast Student ID lookup; resizes when the load factor would exceed 0.75 |
| Graph | `CampusGraph`: adjacency lists backed by `LinkedHashMap` and `LinkedHashSet` | Locations as vertices, two-way roads as edges, neighbour display and BFS |

The five list/stack/queue/tree/hash structures are implemented directly, rather than delegated to equivalent Java collections. Java collections are used for the graph adjacency lists, visited vertices, and returned snapshots.

`StudentRegistry` coordinates every add, update, and delete across the linked list, BST, and hash table. `Student` objects are immutable, and updates replace the record in all three structures. IDs cannot be changed by the update menu. The returned record collections are read-only snapshots.

The BST uses **lexicographic**, not numeric, Student ID ordering: for example, `S1`, `S10`, `S2`. Use padded IDs such as `S001`, `S002`, and `S010` if numeric-looking order is needed. This is an ordinary BST, not an AVL tree. Its iterative operations avoid recursive stack overflow when the tree is skewed.

The graph is **undirected and unweighted**. Every road is stored in both endpoint adjacency lists. Removing a location removes all references to it. Display and BFS use insertion order for deterministic results. BFS marks vertices visited when enqueuing them, so cycles cannot cause repeated visits. It visits only locations reachable from the selected start; the console reports any unreachable locations. **BFS output is a visit order, not a driving/walking route between consecutive entries.**

### Expected operation costs

Here `n` is the number of students, `h` the BST height, and `V`/`E` the graph's vertex/edge counts.

| Operation | Time |
| --- | --- |
| Linked-list append | O(1) |
| Linked-list update/delete/display | O(n) |
| Stack push/pop; queue enqueue/dequeue | O(1) |
| BST search/insert/delete | O(h); O(n) worst case for a skewed tree |
| BST in-order display | O(n) |
| Hash lookup/insert/delete | O(1) expected (amortized for insert); O(n) worst case |
| Complete student update/delete | O(n), because the linked list must be scanned |
| Add location or add/remove road | O(1) expected, excluding the length of location names |
| Remove location | O(degree) expected |
| Campus display or BFS | O(V + E); BFS visits the reachable component only |

## Validation and behavior

- Student IDs are required, trimmed, and converted to uppercase. Only letters `A-Z`, digits, hyphens, and underscores are accepted. Duplicate IDs are rejected regardless of case.
- Names, programmes, service descriptions, and location names cannot be blank.
- Marks must be finite numbers between **0 and 100 inclusive**. Decimal marks are accepted; display uses two decimal places. `NaN` and infinity are rejected.
- During updates, an empty field keeps its current value. The student must already exist.
- New service requests require an existing student. Requests capture the ID and name at submission time and stay in the FIFO queue even if the student is later updated or deleted. Reusing a deleted ID does not change the captured details of an old request.
- The stack records successful student changes, queue operations, and campus changes. Failed operations and read-only displays/searches do not create history entries. Viewing history does not consume it. This is an action-history feature, not undo.
- Location matching ignores case, surrounding whitespace, and repeated internal whitespace. Display preserves the capitalization entered when the location was added.
- Roads require two existing, distinct locations. Duplicate roads (including reversed duplicates), self-connections, missing locations, and nonexistent roads are rejected.
- Empty collections produce explanatory messages. Invalid menu/field input is reprompted; invalid operations return to the menu. End-of-input exits cleanly, including during partially entered operations.

## Suggested demonstration

1. Use option **1** to add `S002`, `Nimal Perera`, `Computing`, `82.5`, then `S001`, `Amali Silva`, `Engineering`, `91`.
2. Use **4** to see insertion order (`S002`, `S001`), then **8** to see BST order (`S001`, `S002`).
3. Use **9** to search `s002`; use **2** to update its marks, leaving other fields blank. Verify the new value in **4**, **8**, and **9**.
4. Use **5** to submit a transcript request for `S002`, then an ID card request for `S001`. Use **6** twice to demonstrate FIFO processing.
5. Use **3** to delete `S002`, and **7** to inspect recent actions with the deletion at the top.
6. Use **10** to add `Main Gate`, `Library`, `Lab`, `Cafeteria`, and `Hostel`.
7. Use **12** to add `Main Gate`–`Library`, `Main Gate`–`Lab`, `Library`–`Cafeteria`, and `Lab`–`Cafeteria`.
8. Use **14** to display neighbours. Use **15**, starting at `Main Gate`, to see `Main Gate -> Library -> Lab -> Cafeteria`. `Hostel` is unreachable.
9. Use **13** to remove a road, then **11** to remove `Cafeteria`. Use **14** again to verify there are no dangling connections.
10. Demonstrate validation using duplicate student IDs, marks of `101`, a missing student ID, a reversed duplicate road, and an empty queue.

## Tests

On Windows:

```powershell
.\test.bat
```

Or:

```text
javac -encoding UTF-8 -Xlint:all -d out src/university/*.java tests/university/*.java
java -cp out university.SystemTests
```

Tests have no external dependencies and fail with an `AssertionError` if a check fails. They cover validation, list head/tail deletion, LIFO/FIFO behavior, hash collisions and resizing, all BST deletion shapes, a skewed BST, randomized cross-index consistency, graph cycles/disconnected vertices/edge cleanup, the complete console menu, invalid input recovery, and end-of-input handling.

## Project layout

```text
src/university/
  Main.java                 Application entry point
  ConsoleApp.java           Menu, validation, action history, service workflow
  Student.java              Validated immutable record
  StudentRegistry.java      Coordinates the three student structures
  StudentLinkedList.java    Custom singly linked list
  LinkedStack.java          Custom generic LIFO stack
  LinkedQueue.java          Custom generic FIFO queue
  StudentBST.java           Custom binary search tree
  StudentHashTable.java     Custom separate-chaining hash table
  ServiceRequest.java       Queued request with submission-time student details
  CampusGraph.java          Adjacency-list graph and BFS
tests/university/
  SystemTests.java          Automated behavioral and console tests
run.bat                     Compile and launch on Windows
test.bat                    Compile and test on Windows
```

## Group-member details and individual contributions

**To be completed by the group before submission.** Member information was not provided, so the table below contains placeholders, not claims about authorship or completed contributions. Add or remove rows to match the actual group and record each person's real work.

| Full name | Student ID | Programme / class | Responsibilities | Actual individual contributions | Demonstration topic |
| -K.A. KAUSHALYA GAYATHRI =22UG3_0302-- | --- | --- | --- | --- | --- |
| [Member 1 full name] | [ID] | [Programme / class] | [Assigned responsibilities] | [Specific classes/features/tests implemented or reviewed] | [What this member will explain] |
| [Member 2 full name] | [ID] | [Programme / class] | [Assigned responsibilities] | [Specific classes/features/tests implemented or reviewed] | [What this member will explain] |
| [Add other members as needed] | [ID] | [Programme / class] | [Assigned responsibilities] | [Actual contributions] | [Demonstration topic] |

Suggested responsibility areas are student records and linked list, stack and service queue, BST and hashing, campus graph and BFS, and console integration/testing/documentation. Allocate these according to the actual group size. Each member should be able to explain the relevant structure, its operations, validation decisions, complexity, and a working demonstration.

## GitHub collaboration

GitHub setup and collaboration are managed by the project owner. No repository, branches, commits, or pull requests have been created by this implementation. Where applicable, use feature branches and pull requests, review each other's changes, and link the real commits/PRs in the contribution table before submission.
