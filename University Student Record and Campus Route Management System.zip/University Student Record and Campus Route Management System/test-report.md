# 📋 Testing & Validation Report

**Project:** University Student Record and Campus Route Management System
**Date:** 2026-09-29
**Tester:** Nilupul Madhusanka
**Verdict:** ✅ All 14 system requirements are met. All 52,268 automated checks pass. No critical bugs found.

---

## 1. Executive Summary

The project is **well-implemented and fully functional**. All required data structures (linked list, stack, queue, BST, hash table, graph) are implemented from scratch as custom classes — not delegated to Java collections. The code compiles cleanly, all automated tests pass, and the console application handles both valid and invalid inputs gracefully. The README is thorough and accurate.

There are a few **minor issues and observations** (detailed below) that don't break functionality but are worth knowing about.

---

## 2. Requirement-by-Requirement Validation

| Req # | Requirement | Status | Evidence |
|-------|-------------|--------|----------|
| 1 | Store student records with ID, Name, Programme, Marks | ✅ Pass | [`Student.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/Student.java) stores all four fields. Immutable design keeps data consistent across structures. |
| 2 | Use a linked list to store and manage student records | ✅ Pass | [`StudentLinkedList.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/StudentLinkedList.java) — Custom singly linked list with head/tail pointers, supporting add, replace, remove, and iteration. |
| 3 | Use a stack for recent actions / history | ✅ Pass | [`LinkedStack.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/LinkedStack.java) — Generic LIFO stack with push, pop, peek. Used for timestamped action history (menu option 7). Non-destructive iteration. |
| 4 | Use a queue for student service requests (FIFO) | ✅ Pass | [`LinkedQueue.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/LinkedQueue.java) — Generic FIFO queue with enqueue/dequeue. Processes requests in arrival order (menu options 5 & 6). |
| 5 | Use a BST to organize/search student records | ✅ Pass | [`StudentBST.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/StudentBST.java) — Unbalanced BST keyed by Student ID. Supports put, find, remove (all 3 deletion cases), and in-order traversal. Iterative traversal uses `LinkedStack` internally. |
| 6 | Use hashing for efficient student ID searching | ✅ Pass | [`StudentHashTable.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/StudentHashTable.java) — Separate-chaining hash table with dynamic resizing at 0.75 load factor. Handles collisions correctly. |
| 7 | Use a graph for campus locations and connections | ✅ Pass | [`CampusGraph.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/CampusGraph.java) — Undirected, unweighted graph representing campus locations (vertices) and roads (edges). |
| 8 | Represent graph using adjacency list or matrix | ✅ Pass | Uses adjacency list representation backed by `LinkedHashMap` and `LinkedHashSet` for deterministic ordering. |
| 9 | Provide add/remove for locations and connections | ✅ Pass | Menu options 10–13 cover add/remove location and add/remove connection. Removing a location also cleans up all its incident edges. |
| 10 | Display connected locations / campus network | ✅ Pass | Menu option 14 displays the full adjacency list, including isolated nodes with "(no connections)". |
| 11 | Implement at least one graph traversal (BFS or DFS) | ✅ Pass | BFS implemented in [`CampusGraph.breadthFirstTraversal()`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/CampusGraph.java#L85-L100). Uses the custom `LinkedQueue`. Reports unreachable locations. |
| 12 | Add, update, delete, search, display for student records | ✅ Pass | Menu options 1–4, 8, 9 cover all CRUD + display + search. Update allows partial field changes (press Enter to keep current value). |
| 13 | Menu-driven console with suitable input validation | ✅ Pass | 16-option menu in [`ConsoleApp.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/ConsoleApp.java). Re-prompts on invalid menu choices. Status bar shows counts. |
| 14 | Handle invalid inputs, duplicates, missing records, invalid marks, unavailable connections | ✅ Pass | Comprehensive validation (see Section 4 below for full test results). |

---

## 3. Data Structure Implementation Review

### 3.1 Linked List — [`StudentLinkedList.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/StudentLinkedList.java)

| Aspect | Assessment |
|--------|------------|
| Custom implementation | ✅ Manual `Node` class, not using `java.util.LinkedList` |
| Add (append) | ✅ O(1) with tail pointer |
| Replace (update) | ✅ O(n) linear scan by ID |
| Remove | ✅ Handles head, middle, and tail removal correctly |
| Tail pointer maintenance | ✅ Updates tail on head removal, tail removal, and empty list |
| Iterator | ✅ Implements `Iterable<Student>` for `for-each` usage |
| Edge cases | ✅ Empty list removal returns null; reuse after emptying works |

### 3.2 Stack — [`LinkedStack.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/LinkedStack.java)

| Aspect | Assessment |
|--------|------------|
| Custom implementation | ✅ Generic linked-node stack |
| Push / Pop / Peek | ✅ All O(1) |
| Empty stack handling | ✅ Throws `NoSuchElementException` |
| Non-destructive iteration | ✅ `for-each` traversal doesn't consume the stack |
| Dual usage | ✅ Used for action history AND iterative BST in-order traversal |

### 3.3 Queue — [`LinkedQueue.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/LinkedQueue.java)

| Aspect | Assessment |
|--------|------------|
| Custom implementation | ✅ Generic front/rear linked queue |
| Enqueue / Dequeue / Peek | ✅ All O(1) |
| FIFO order | ✅ Verified by automated tests and manual testing |
| Empty queue handling | ✅ Throws `NoSuchElementException` |
| Dual usage | ✅ Used for service requests AND BFS frontier |

### 3.4 BST — [`StudentBST.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/StudentBST.java)

| Aspect | Assessment |
|--------|------------|
| Custom implementation | ✅ Manual left/right child nodes |
| Insert (put) | ✅ Inserts new or replaces existing by ID |
| Find | ✅ Standard BST search |
| Delete — leaf | ✅ Tested |
| Delete — one child | ✅ Tested |
| Delete — two children (in-order successor) | ✅ Tested, including deep successor chains |
| In-order traversal | ✅ **Iterative** (uses `LinkedStack`), avoids StackOverflow on skewed trees |
| Skewed tree test | ✅ 1,500-node sequential insert + traversal passes without recursion issues |
| Ordering note | ⚠️ Lexicographic order, not numeric (S1 < S10 < S2). Documented in README. |

### 3.5 Hash Table — [`StudentHashTable.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/StudentHashTable.java)

| Aspect | Assessment |
|--------|------------|
| Custom implementation | ✅ Manual bucket array with entry chains |
| Collision handling | ✅ Separate chaining |
| Dynamic resizing | ✅ Doubles capacity when load > 0.75 |
| Get / Put / Remove | ✅ All correctly maintain chains |
| Large-scale test | ✅ 1,000 inserts → rehash → all lookups succeed → all removals succeed |
| Index function | ✅ Uses `Math.floorMod` to avoid negative indices |

### 3.6 Graph — [`CampusGraph.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/CampusGraph.java)

| Aspect | Assessment |
|--------|------------|
| Adjacency list representation | ✅ `LinkedHashMap<String, Location>` with `LinkedHashSet<String>` for neighbours |
| Undirected edges | ✅ `addConnection` and `removeConnection` update both endpoints |
| Add / Remove location | ✅ Remove cleans up all incident edges from all neighbours |
| Add / Remove connection | ✅ With duplicate, self-loop, and missing-location validation |
| BFS traversal | ✅ Uses custom `LinkedQueue`, marks visited on enqueue to prevent revisits |
| Disconnected vertices | ✅ BFS reports count of unreachable locations |
| Case-insensitive matching | ✅ Normalizes to lowercase; preserves original display name |
| Deterministic display order | ✅ `LinkedHashMap`/`LinkedHashSet` maintain insertion order |

### 3.7 Registry — [`StudentRegistry.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/StudentRegistry.java)

| Aspect | Assessment |
|--------|------------|
| Three-structure synchronization | ✅ Every add/update/delete propagates to linked list, BST, and hash table |
| Consistency under randomized workload | ✅ 700-step randomized test with 80 IDs verifies all three structures agree at every step |
| Duplicate ID prevention | ✅ `add()` checks hash table first |
| Missing ID detection | ✅ `requireStudent()` throws `IllegalArgumentException` |

---

## 4. Input Validation Testing

### 4.1 Student ID Validation

| Input | Expected | Actual | Status |
|-------|----------|--------|--------|
| `S1` | Accepted, normalized to `S1` | ✅ `S1` | Pass |
| `s1` (lowercase) | Normalized to `S1` | ✅ `S1` | Pass |
| ` s_01 ` (whitespace + underscore) | Normalized to `S_01` | ✅ `S_01` | Pass |
| Empty / blank | Rejected | ✅ "Student ID cannot be blank." | Pass |
| `S 01` (space in ID) | Rejected | ✅ "Student ID may contain only letters, digits, '-' and '_'." | Pass |
| `S/01` (slash in ID) | Rejected | ✅ Rejected | Pass |

### 4.2 Marks Validation

| Input | Expected | Actual | Status |
|-------|----------|--------|--------|
| `0` | Accepted | ✅ `0.00` | Pass |
| `100` | Accepted | ✅ `100.00` | Pass |
| `80.5` | Accepted | ✅ `80.50` | Pass |
| `-1` | Rejected | ✅ "Marks must be a finite number from 0 to 100." | Pass |
| `101` | Rejected | ✅ Rejected | Pass |
| `100.01` | Rejected | ✅ Rejected | Pass |
| `NaN` | Rejected | ✅ Rejected | Pass |
| `Infinity` | Rejected | ✅ Rejected | Pass |
| `abc` (text) | Rejected | ✅ Re-prompts | Pass |

### 4.3 Menu Input Validation

| Input | Expected | Actual | Status |
|-------|----------|--------|--------|
| `abc` (text) | Re-prompt | ✅ "Please enter a whole number from 1 to 16." | Pass |
| `0` | Re-prompt | ✅ Re-prompts | Pass |
| `17` | Re-prompt | ✅ Re-prompts | Pass |
| `1.5` (decimal) | Re-prompt | ✅ Re-prompts | Pass |

### 4.4 Duplicate & Missing Record Validation

| Scenario | Expected | Actual | Status |
|----------|----------|--------|--------|
| Add duplicate Student ID | Rejected | ✅ "Student ID already exists: S1" | Pass |
| Update non-existent student | Rejected | ✅ "Student record not found: S99" | Pass |
| Delete non-existent student | Rejected | ✅ "Student record not found: S99" | Pass |
| Search non-existent student | Not found | ✅ "Student record not found." | Pass |
| Service request for non-existent student | Rejected | ✅ "Student record not found: S99" | Pass |
| Blank name/programme | Rejected | ✅ "This field cannot be blank." | Pass |

### 4.5 Graph Validation

| Scenario | Expected | Actual | Status |
|----------|----------|--------|--------|
| Duplicate location (case-insensitive) | Rejected | ✅ "Campus location already exists" | Pass |
| Connection to missing location | Rejected | ✅ "Campus location not found: Missing" | Pass |
| Self-connection (Library → Library) | Rejected | ✅ "A road must connect two different locations." | Pass |
| Duplicate connection | Rejected | ✅ "A connection already exists between these locations." | Pass |
| Remove non-existent connection | Rejected | ✅ "No connection exists between these locations." | Pass |
| Remove non-existent location | Rejected | ✅ "Campus location not found" | Pass |
| BFS from non-existent location | Rejected | ✅ "Campus location not found" | Pass |

### 4.6 Edge Cases

| Scenario | Expected | Actual | Status |
|----------|----------|--------|--------|
| Process empty queue | Message | ✅ "No service requests pending." | Pass |
| Display history when empty | Message | ✅ "No actions recorded yet." | Pass |
| Display students when none exist | Message | ✅ "No student records available." | Pass |
| Display campus when no locations | Message | ✅ "No campus locations available." | Pass |
| BFS when no locations exist | Message | ✅ "No campus locations available." | Pass |
| EOF (Ctrl+Z/Ctrl+D) mid-operation | Clean exit | ✅ "Input closed. Goodbye." without crash | Pass |
| EOF during partial add | No record created | ✅ No partial record saved | Pass |
| Request for deleted student | Queue retains original details | ✅ "this request retains the original student details." | Pass |

---

## 5. Automated Test Results

```
PASS: 52,268 checks across 8 test groups.
```

| Test Group | What It Covers |
|------------|---------------|
| `testValidation` | Student ID normalization, blank fields, marks boundaries, NaN/Infinity |
| `testLinkedStructures` | Linked list head/tail removal, stack LIFO, queue FIFO, reuse after emptying |
| `testHashCollisionsAndResize` | Collision between `A` and `Q`, 1,000 inserts triggering multiple rehashes, removal from chains |
| `testTreeDeletion` | All BST deletion cases: leaf, one child, two children, deep successor, root, skewed tree of 1,500 nodes |
| `testRegistryConsistency` | 700 randomized add/update/delete operations verifying linked list, BST, and hash table agree at every step |
| `testCampusGraph` | Edge validation, BFS cycle handling, disconnected vertex, location removal cleanup, re-add behavior |
| `testConsoleWorkflow` | Full end-to-end menu interaction with expected output strings, FIFO processing order, history ordering |
| `testEndOfInput` | EOF at menu prompt, EOF during partial student creation |

> [!TIP]
> The test suite is **dependency-free** (no JUnit required) and uses a custom `check()` / `expect()` pattern. This is a smart choice for a project with a "no external dependencies" requirement. The randomized registry consistency test is particularly impressive — it exercises the system far more thoroughly than typical student project tests.

---

## 6. Issues & Observations

### 6.1 Minor Issues Found

| # | Severity | Issue | File | Details |
|---|----------|-------|------|---------|
| 1 | ⚠️ Minor | **BST is unbalanced** | [`StudentBST.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/StudentBST.java) | The requirement says "BST **or AVL tree**". An unbalanced BST is acceptable per the spec, but sequential ID inserts (S001, S002, ...) degrade to O(n) search. Documented in README. |
| 2 | ⚠️ Minor | **Lexicographic ID ordering** | [`StudentBST.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/StudentBST.java) | BST sorts `S1 < S10 < S2` (string order, not numeric). Documented in README with workaround (use padded IDs). |
| 3 | ⚠️ Minor | **No data persistence** | General | All data is lost on exit. Acceptable for this assignment since persistence is not required, and it's clearly documented. |
| 4 | 💡 Note | **No DFS implementation** | [`CampusGraph.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/CampusGraph.java) | Only BFS is implemented. The spec requires "at least one" (BFS or DFS), so this is fine. |
| 5 | 💡 Note | **Graph uses Java collections internally** | [`CampusGraph.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/CampusGraph.java) | `LinkedHashMap` and `LinkedHashSet` are used for the adjacency list. The five other data structures (list, stack, queue, BST, hash table) are fully custom. The README explicitly acknowledges this design choice. |
| 6 | ⚠️ Minor | **README group-member table is placeholder** | [`README.md`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/README.md#L145-L155) | The member contributions table has `[Member 1 full name]` placeholders. **Must be filled before submission.** |
| 7 | ⚠️ Minor | **No GitHub collaboration evidence** | [`README.md`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/README.md#L157-L159) | README states "No repository, branches, commits, or pull requests have been created." The spec requires using GitHub features. **Must be addressed before submission.** |
| 8 | 💡 Note | **Location name "10" accepted** | [`CampusGraph.java`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/src/university/CampusGraph.java) | Pure numeric strings like "10" are accepted as location names. Not a bug, but could lead to confusing displays. |

### 6.2 Code Quality Observations

| Aspect | Rating | Comment |
|--------|--------|---------|
| Naming conventions | ⭐⭐⭐⭐⭐ | Meaningful class, method, and variable names throughout |
| Code organization | ⭐⭐⭐⭐⭐ | Clean separation: data structures → registry → console UI |
| Comments & Javadoc | ⭐⭐⭐⭐ | Good class-level Javadoc; methods are self-documenting |
| Error handling | ⭐⭐⭐⭐⭐ | Consistent use of `IllegalArgumentException`, clean EOF handling |
| Immutability | ⭐⭐⭐⭐⭐ | `Student` is immutable; returned lists are unmodifiable snapshots |
| Test coverage | ⭐⭐⭐⭐⭐ | Excellent — randomized consistency tests, edge cases, collision tests |
| README quality | ⭐⭐⭐⭐ | Thorough documentation including complexity analysis (missing member info) |
| Readability | ⭐⭐⭐⭐⭐ | Clean, consistent formatting; no unnecessary complexity |

---

## 7. Architecture Diagram

```mermaid
graph TD
    A["Main.java"] --> B["ConsoleApp.java"]
    B --> C["StudentRegistry.java"]
    B --> D["LinkedStack - History"]
    B --> E["LinkedQueue - Service Requests"]
    B --> F["CampusGraph.java"]
    C --> G["StudentLinkedList.java"]
    C --> H["StudentBST.java"]
    C --> I["StudentHashTable.java"]
    H -.->|"uses for traversal"| D2["LinkedStack"]
    F -.->|"uses for BFS"| E2["LinkedQueue"]
    G --> J["Student.java"]
    H --> J
    I --> J
    E --> K["ServiceRequest.java"]
```

---

## 8. Action Items Before Submission

> [!IMPORTANT]
> The following items **must** be addressed before final submission:

1. **Fill in the group-member contribution table** in [`README.md`](file:///c:/Users/Nilupul%20Madhusanka/Desktop/new/University%20Student%20Record%20and%20Campus%20Route%20Management%20System/README.md#L149-L153) — replace all `[placeholder]` values with actual names, IDs, and contributions.
2. **Set up GitHub collaboration** — create branches, make meaningful commits, and use pull requests as required by the implementation guidelines.
3. **Each member must be able to explain and demonstrate their own contribution** during the demo.

---

## 9. Final Verdict

| Category | Score |
|----------|-------|
| Functional Completeness | **14 / 14 requirements met** |
| Data Structure Implementation | **5 / 5 custom** (linked list, stack, queue, BST, hash table) + 1 using Java collections (graph) |
| Input Validation | **Comprehensive** — all invalid inputs handled gracefully |
| Test Suite | **52,268 checks, all passing** |
| Code Quality | **Excellent** |
| Documentation | **Good** (missing member info) |

> [!NOTE]
> **Overall Assessment:** The project is well-engineered and submission-ready from a code perspective. The only gaps are administrative — filling in the group member table and setting up GitHub collaboration evidence. The code itself is clean, well-tested, and fully meets all 14 system requirements.
