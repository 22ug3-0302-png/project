@echo off
setlocal
cd /d "%~dp0"
if not exist out mkdir out
javac -encoding UTF-8 -Xlint:all -d out src\university\*.java tests\university\*.java
if errorlevel 1 exit /b 1
java -cp out university.SystemTests
