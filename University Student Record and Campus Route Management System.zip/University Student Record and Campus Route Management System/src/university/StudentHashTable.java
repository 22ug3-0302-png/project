package university;

import java.util.Objects;

/** Separate chaining resolves collisions; rehashing keeps the load factor low. */
public final class StudentHashTable {
    private static final class Entry {
        private Student student;
        private Entry next;
        private Entry(Student student, Entry next) { this.student = student; this.next = next; }
    }

    private Entry[] buckets = new Entry[16];
    private int size;

    private int index(String id) { return Math.floorMod(id.hashCode(), buckets.length); }

    public Student get(String id) {
        String key = Student.normalizeId(id);
        for (Entry entry = buckets[index(key)]; entry != null; entry = entry.next) {
            if (entry.student.getId().equals(key)) { return entry.student; }
        }
        return null;
    }

    public void put(Student student) {
        Objects.requireNonNull(student);
        int bucket = index(student.getId());
        for (Entry entry = buckets[bucket]; entry != null; entry = entry.next) {
            if (entry.student.getId().equals(student.getId())) {
                entry.student = student;
                return;
            }
        }
        if ((size + 1) > buckets.length * 0.75) {
            resize();
            bucket = index(student.getId());
        }
        buckets[bucket] = new Entry(student, buckets[bucket]);
        size++;
    }

    private void resize() {
        Entry[] old = buckets;
        buckets = new Entry[old.length * 2];
        for (Entry first : old) {
            Entry entry = first;
            while (entry != null) {
                Entry next = entry.next;
                int bucket = index(entry.student.getId());
                entry.next = buckets[bucket];
                buckets[bucket] = entry;
                entry = next;
            }
        }
    }

    public Student remove(String id) {
        String key = Student.normalizeId(id);
        int bucket = index(key);
        Entry previous = null;
        Entry entry = buckets[bucket];
        while (entry != null) {
            if (entry.student.getId().equals(key)) {
                if (previous == null) { buckets[bucket] = entry.next; }
                else { previous.next = entry.next; }
                size--;
                return entry.student;
            }
            previous = entry;
            entry = entry.next;
        }
        return null;
    }

    public int size() { return size; }
}
