package university;

import java.util.Locale;

/** Immutable records keep the list, tree and hash index consistent. */
public final class Student {
    private final String id;
    private final String name;
    private final String programme;
    private final double marks;

    public Student(String id, String name, String programme, double marks) {
        this.id = normalizeId(id);
        this.name = requireText(name, "Name");
        this.programme = requireText(programme, "Programme");
        if (!Double.isFinite(marks) || marks < 0 || marks > 100) {
            throw new IllegalArgumentException("Marks must be a finite number from 0 to 100.");
        }
        this.marks = marks;
    }

    public static String normalizeId(String id) {
        String normalized = requireText(id, "Student ID").toUpperCase(Locale.ROOT);
        if (!normalized.matches("[A-Z0-9_-]+")) {
            throw new IllegalArgumentException("Student ID may contain only letters, digits, '-' and '_'.");
        }
        return normalized;
    }

    public static String requireText(String value, String label) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(label + " cannot be blank.");
        }
        return value.trim();
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getProgramme() { return programme; }
    public double getMarks() { return marks; }

    @Override
    public String toString() {
        return String.format(Locale.ROOT, "%s | %s | %s | %.2f", id, name, programme, marks);
    }
}
