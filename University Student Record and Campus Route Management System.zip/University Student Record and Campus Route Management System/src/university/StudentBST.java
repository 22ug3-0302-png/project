package university;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Unbalanced BST keyed by normalized Student ID (lexicographic order). */
public final class StudentBST {
    private static final class Node {
        private Student student;
        private Node left;
        private Node right;
        private Node(Student student) { this.student = student; }
    }

    private Node root;

    /** Inserts a new ID or replaces the record for an existing ID. */
    public void put(Student student) {
        Objects.requireNonNull(student);
        if (root == null) { root = new Node(student); return; }
        Node current = root;
        while (true) {
            int comparison = student.getId().compareTo(current.student.getId());
            if (comparison == 0) { current.student = student; return; }
            if (comparison < 0) {
                if (current.left == null) { current.left = new Node(student); return; }
                current = current.left;
            } else {
                if (current.right == null) { current.right = new Node(student); return; }
                current = current.right;
            }
        }
    }

    public Student find(String id) {
        String key = Student.normalizeId(id);
        Node current = root;
        while (current != null) {
            int comparison = key.compareTo(current.student.getId());
            if (comparison == 0) { return current.student; }
            current = comparison < 0 ? current.left : current.right;
        }
        return null;
    }

    public boolean remove(String id) {
        String key = Student.normalizeId(id);
        Node parent = null;
        Node current = root;
        while (current != null && !key.equals(current.student.getId())) {
            parent = current;
            current = key.compareTo(current.student.getId()) < 0 ? current.left : current.right;
        }
        if (current == null) { return false; }

        // For two children, copy the in-order successor then unlink that successor.
        if (current.left != null && current.right != null) {
            Node successorParent = current;
            Node successor = current.right;
            while (successor.left != null) {
                successorParent = successor;
                successor = successor.left;
            }
            current.student = successor.student;
            parent = successorParent;
            current = successor;
        }
        Node child = current.left != null ? current.left : current.right;
        if (parent == null) {
            root = child;
        } else if (parent.left == current) {
            parent.left = child;
        } else {
            parent.right = child;
        }
        return true;
    }

    public List<Student> inOrder() {
        List<Student> result = new ArrayList<>();
        LinkedStack<Node> pending = new LinkedStack<>();
        Node current = root;
        // Iterative traversal also handles a deeply skewed BST without recursion.
        while (current != null || !pending.isEmpty()) {
            while (current != null) { pending.push(current); current = current.left; }
            current = pending.pop();
            result.add(current.student);
            current = current.right;
        }
        return result;
    }
}
