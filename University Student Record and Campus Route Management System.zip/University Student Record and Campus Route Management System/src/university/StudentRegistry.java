package university;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/** All record mutations pass through here to update all three structures. */
public final class StudentRegistry {
    private final StudentLinkedList records = new StudentLinkedList();
    private final StudentBST tree = new StudentBST();
    private final StudentHashTable index = new StudentHashTable();

    public void add(Student student) {
        Objects.requireNonNull(student);
        if (index.get(student.getId()) != null) {
            throw new IllegalArgumentException("Student ID already exists: " + student.getId());
        }
        records.add(student);
        tree.put(student);
        index.put(student);
    }

    public void update(Student student) {
        Objects.requireNonNull(student);
        requireStudent(student.getId());
        records.replace(student);
        tree.put(student);
        index.put(student);
    }

    public Student delete(String id) {
        Student student = requireStudent(id);
        records.remove(student.getId());
        tree.remove(student.getId());
        index.remove(student.getId());
        return student;
    }

    public Student searchByHash(String id) { return index.get(id); }
    public Student searchByTree(String id) { return tree.find(id); }

    public Student requireStudent(String id) {
        Student student = searchByHash(id);
        if (student == null) { throw new IllegalArgumentException("Student record not found: " + id); }
        return student;
    }

    public List<Student> insertionOrder() {
        List<Student> snapshot = new ArrayList<>();
        for (Student student : records) { snapshot.add(student); }
        return Collections.unmodifiableList(snapshot);
    }

    public List<Student> sortedById() { return Collections.unmodifiableList(tree.inOrder()); }
    public int size() { return records.size(); }
}
