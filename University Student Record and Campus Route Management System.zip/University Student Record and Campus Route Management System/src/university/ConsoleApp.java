package university;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/** Console input/output is separate from the data structures for easier testing. */
public final class ConsoleApp {
    private final BufferedReader input;
    private final PrintWriter output;
    private final StudentRegistry students = new StudentRegistry();
    private final LinkedStack<String> history = new LinkedStack<>();
    private final LinkedQueue<ServiceRequest> requests = new LinkedQueue<>();
    private final CampusGraph campus = new CampusGraph();
    private long nextRequestNumber = 1;

    public ConsoleApp(Reader input, PrintWriter output) {
        this.input = new BufferedReader(input);
        this.output = output;
    }

    public void run() {
        output.println("University Student Record and Campus Route Management System");
        output.println("Data is kept in memory for this session. Marks must be from 0 to 100.");
        try {
            while (true) {
                showMenu();
                int choice = readChoice();
                if (choice == 16) {
                    output.println("Goodbye. Session data has not been saved.");
                    return;
                }
                try {
                    execute(choice);
                } catch (IllegalArgumentException exception) {
                    output.println("Unable to complete operation: " + exception.getMessage());
                }
            }
        } catch (EOFException exception) {
            output.println("\nInput closed. Goodbye. Session data has not been saved.");
        } catch (IOException exception) {
            output.println("Unable to read console input: " + exception.getMessage());
        } finally {
            output.flush();
        }
    }

    private void showMenu() {
        output.println("\n---------------- MAIN MENU ----------------");
        output.println("1.  Add Student Record");
        output.println("2.  Update Student Record");
        output.println("3.  Delete Student Record");
        output.println("4.  Display All Records using Linked List");
        output.println("5.  Add Service Request to Queue");
        output.println("6.  Process Next Service Request");
        output.println("7.  Display Recent Actions using Stack");
        output.println("8.  Display Students using BST");
        output.println("9.  Search Student using Hashing");
        output.println("10. Add Campus Location");
        output.println("11. Remove Campus Location");
        output.println("12. Add Campus Connection/Road");
        output.println("13. Remove Campus Connection/Road");
        output.println("14. Display Campus Connections");
        output.println("15. Traverse Campus Locations using BFS");
        output.println("16. Exit");
        output.println("Students: " + students.size() + " | Pending requests: " + requests.size()
                + " | Locations: " + campus.size());
    }

    private int readChoice() throws IOException {
        while (true) {
            try {
                int choice = Integer.parseInt(readLine("Choose an option (1-16): "));
                if (choice >= 1 && choice <= 16) { return choice; }
            } catch (NumberFormatException exception) {
                // A single line is consumed so malformed input cannot trap the menu.
            }
            output.println("Please enter a whole number from 1 to 16.");
        }
    }

    private void execute(int choice) throws IOException {
        switch (choice) {
            case 1: addStudent(); break;
            case 2: updateStudent(); break;
            case 3: deleteStudent(); break;
            case 4: displayStudents(students.insertionOrder(), "Linked list: insertion order"); break;
            case 5: addRequest(); break;
            case 6: processRequest(); break;
            case 7: displayHistory(); break;
            case 8: displayStudents(students.sortedById(), "BST: ascending Student ID"); break;
            case 9: searchStudent(); break;
            case 10: addLocation(); break;
            case 11: removeLocation(); break;
            case 12: changeConnection(true); break;
            case 13: changeConnection(false); break;
            case 14: displayCampus(); break;
            case 15: traverseCampus(); break;
            default: throw new IllegalArgumentException("Unknown menu option.");
        }
    }

    private void addStudent() throws IOException {
        String id = readId();
        if (students.searchByHash(id) != null) {
            throw new IllegalArgumentException("Student ID already exists: " + id);
        }
        Student student = new Student(id, readText("Name: "), readText("Programme: "), readMarks(null));
        students.add(student);
        recordAction("Added student: " + student);
        output.println("Student added successfully.");
    }

    private void updateStudent() throws IOException {
        Student previous = students.requireStudent(readId());
        output.println("Current record: " + previous);
        output.println("Student ID stays unchanged. Press Enter to keep a field's current value.");
        String name = readLine("Name [" + previous.getName() + "]: ");
        String programme = readLine("Programme [" + previous.getProgramme() + "]: ");
        double marks = readMarks(previous.getMarks());
        Student updated = new Student(previous.getId(),
                name.isEmpty() ? previous.getName() : name,
                programme.isEmpty() ? previous.getProgramme() : programme, marks);
        students.update(updated);
        recordAction("Updated student from {" + previous + "} to {" + updated + "}");
        output.println("Student updated successfully.");
    }

    private void deleteStudent() throws IOException {
        Student deleted = students.delete(readId());
        recordAction("Deleted student: " + deleted);
        output.println("Student deleted successfully. Existing queued requests are retained.");
    }

    private void displayStudents(List<Student> records, String heading) {
        output.println("\n" + heading);
        if (records.isEmpty()) { output.println("No student records available."); return; }
        output.println("Student ID | Name | Programme | Marks");
        for (Student student : records) { output.println(student); }
        output.println("Total records: " + records.size());
    }

    private void searchStudent() throws IOException {
        Student student = students.searchByHash(readId());
        if (student == null) { output.println("Student record not found."); }
        else {
            output.println("Found using the hash table:");
            output.println("Student ID | Name | Programme | Marks");
            output.println(student);
        }
    }

    private void addRequest() throws IOException {
        Student student = students.requireStudent(readId());
        ServiceRequest request = new ServiceRequest(nextRequestNumber, student,
                readText("Service request description: "));
        requests.enqueue(request);
        nextRequestNumber++;
        recordAction("Queued " + request);
        output.println("Added to service queue: " + request);
    }

    private void processRequest() {
        if (requests.isEmpty()) { output.println("No service requests pending."); return; }
        ServiceRequest request = requests.dequeue();
        output.println("Processing: " + request);
        if (students.searchByHash(request.getStudentId()) == null) {
            output.println("The student record was deleted; this request retains the original student details.");
        }
        recordAction("Processed " + request);
        output.println("Remaining requests: " + requests.size());
    }

    private void recordAction(String action) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        history.push("[" + timestamp + "] " + action);
    }

    private void displayHistory() {
        output.println("\nAction history (newest first):");
        if (history.isEmpty()) { output.println("No actions recorded yet."); return; }
        for (String action : history) { output.println(action); }
    }

    private void addLocation() throws IOException {
        String name = readText("New campus location: ");
        campus.addLocation(name);
        recordAction("Added campus location: " + name);
        output.println("Campus location added successfully.");
    }

    private void removeLocation() throws IOException {
        String name = readText("Campus location to remove: ");
        campus.removeLocation(name);
        recordAction("Removed campus location and its incident roads: " + name);
        output.println("Location and all its connections removed successfully.");
    }

    private void changeConnection(boolean add) throws IOException {
        String from = readText("First location: ");
        String to = readText("Second location: ");
        if (add) { campus.addConnection(from, to); }
        else { campus.removeConnection(from, to); }
        recordAction((add ? "Added" : "Removed") + " road: " + from + " <-> " + to);
        output.println(add ? "Two-way connection added successfully." : "Connection removed successfully.");
    }

    private void displayCampus() {
        Map<String, List<String>> adjacency = campus.adjacencyList();
        if (adjacency.isEmpty()) { output.println("No campus locations available."); return; }
        output.println("\nCampus adjacency list (all roads are two-way):");
        for (Map.Entry<String, List<String>> entry : adjacency.entrySet()) {
            output.println(entry.getKey() + " -> " + (entry.getValue().isEmpty()
                    ? "(no connections)" : String.join(", ", entry.getValue())));
        }
    }

    private void traverseCampus() throws IOException {
        if (campus.size() == 0) { output.println("No campus locations available."); return; }
        List<String> order = campus.breadthFirstTraversal(readText("Starting location: "));
        output.println("BFS visit order: " + String.join(" -> ", order));
        output.println("Visited " + order.size() + " of " + campus.size() + " locations.");
        output.println("This is a traversal order; consecutive entries may not share a road.");
        if (order.size() < campus.size()) {
            output.println("Other locations are unreachable from the starting location.");
        }
    }

    private String readLine(String prompt) throws IOException {
        output.print(prompt);
        output.flush();
        String line = input.readLine();
        if (line == null) { throw new EOFException(); }
        return line.trim();
    }

    private String readText(String prompt) throws IOException {
        while (true) {
            String value = readLine(prompt);
            if (!value.isEmpty()) { return value; }
            output.println("This field cannot be blank.");
        }
    }

    private String readId() throws IOException {
        while (true) {
            try { return Student.normalizeId(readLine("Student ID: ")); }
            catch (IllegalArgumentException exception) { output.println(exception.getMessage()); }
        }
    }

    private double readMarks(Double current) throws IOException {
        while (true) {
            String value = readLine(current == null ? "Marks (0-100): " : "Marks [" + current + "]: ");
            if (current != null && value.isEmpty()) { return current; }
            try {
                double marks = Double.parseDouble(value);
                if (Double.isFinite(marks) && marks >= 0 && marks <= 100) { return marks; }
            } catch (NumberFormatException exception) {
                // Repeat the prompt for malformed numeric input.
            }
            output.println("Marks must be a finite number from 0 to 100.");
        }
    }
}
