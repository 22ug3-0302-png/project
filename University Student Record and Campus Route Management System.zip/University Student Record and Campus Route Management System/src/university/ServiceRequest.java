package university;

/** Keeps a submission-time student snapshot even if the record is later deleted. */
public final class ServiceRequest {
    private final long number;
    private final String studentId;
    private final String studentName;
    private final String description;

    public ServiceRequest(long number, Student student, String description) {
        if (number < 1) { throw new IllegalArgumentException("Request number must be positive."); }
        this.number = number;
        this.studentId = student.getId();
        this.studentName = student.getName();
        this.description = Student.requireText(description, "Request description");
    }

    public long getNumber() { return number; }
    public String getStudentId() { return studentId; }

    @Override
    public String toString() {
        return "Request #" + number + " | " + studentId + " | " + studentName + " | " + description;
    }
}
