package university;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

/** Singly linked list; records are displayed in insertion order. */
public final class StudentLinkedList implements Iterable<Student> {
    private static final class Node {
        private Student student;
        private Node next;
        private Node(Student student) { this.student = student; }
    }

    private Node head;
    private Node tail;
    private int size;

    public void add(Student student) {
        Node node = new Node(Objects.requireNonNull(student));
        if (tail == null) {
            head = node;
        } else {
            tail.next = node;
        }
        tail = node;
        size++;
    }

    public boolean replace(Student student) {
        Objects.requireNonNull(student);
        for (Node current = head; current != null; current = current.next) {
            if (current.student.getId().equals(student.getId())) {
                current.student = student;
                return true;
            }
        }
        return false;
    }

    public Student remove(String id) {
        String key = Student.normalizeId(id);
        Node previous = null;
        Node current = head;
        while (current != null) {
            if (current.student.getId().equals(key)) {
                if (previous == null) {
                    head = current.next;
                } else {
                    previous.next = current.next;
                }
                if (current == tail) {
                    tail = previous;
                }
                size--;
                return current.student;
            }
            previous = current;
            current = current.next;
        }
        return null;
    }

    public int size() { return size; }

    @Override
    public Iterator<Student> iterator() {
        return new Iterator<Student>() {
            private Node current = head;
            public boolean hasNext() { return current != null; }
            public Student next() {
                if (!hasNext()) { throw new NoSuchElementException(); }
                Student result = current.student;
                current = current.next;
                return result;
            }
        };
    }
}
