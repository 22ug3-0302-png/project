package university;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

/** Custom LIFO stack. Iteration reads newest to oldest without removing entries. */
public final class LinkedStack<T> implements Iterable<T> {
    private static final class Node<T> {
        private final T value;
        private final Node<T> next;
        private Node(T value, Node<T> next) { this.value = value; this.next = next; }
    }

    private Node<T> top;
    private int size;

    public void push(T value) {
        top = new Node<>(Objects.requireNonNull(value), top);
        size++;
    }

    public T pop() {
        if (isEmpty()) { throw new NoSuchElementException("Stack is empty."); }
        T value = top.value;
        top = top.next;
        size--;
        return value;
    }

    public T peek() {
        if (isEmpty()) { throw new NoSuchElementException("Stack is empty."); }
        return top.value;
    }

    public boolean isEmpty() { return top == null; }
    public int size() { return size; }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            private Node<T> current = top;
            public boolean hasNext() { return current != null; }
            public T next() {
                if (!hasNext()) { throw new NoSuchElementException(); }
                T value = current.value;
                current = current.next;
                return value;
            }
        };
    }
}
