package university;

import java.io.InputStreamReader;
import java.io.PrintWriter;

public final class Main {
    private Main() { }

    public static void main(String[] args) {
        new ConsoleApp(new InputStreamReader(System.in), new PrintWriter(System.out, true)).run();
    }
}
