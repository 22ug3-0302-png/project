package university;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Undirected, unweighted adjacency-list graph with deterministic display order. */
public final class CampusGraph {
    private static final class Location {
        private final String name;
        private final Set<String> neighbours = new LinkedHashSet<>();
        private Location(String name) { this.name = name; }
    }

    private final Map<String, Location> locations = new LinkedHashMap<>();

    private String key(String name) {
        return Student.requireText(name, "Location").replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }

    private Location requireLocation(String name) {
        Location location = locations.get(key(name));
        if (location == null) { throw new IllegalArgumentException("Campus location not found: " + name); }
        return location;
    }

    public void addLocation(String name) {
        String normalized = key(name);
        if (locations.containsKey(normalized)) {
            throw new IllegalArgumentException("Campus location already exists: " + name);
        }
        locations.put(normalized, new Location(name.trim().replaceAll("\\s+", " ")));
    }

    public void removeLocation(String name) {
        Location location = requireLocation(name);
        String normalized = key(name);
        for (String neighbour : location.neighbours) {
            locations.get(neighbour).neighbours.remove(normalized);
        }
        locations.remove(normalized);
    }

    public void addConnection(String from, String to) {
        Location first = requireLocation(from);
        Location second = requireLocation(to);
        String firstKey = key(from);
        String secondKey = key(to);
        if (firstKey.equals(secondKey)) {
            throw new IllegalArgumentException("A road must connect two different locations.");
        }
        if (!first.neighbours.add(secondKey)) {
            throw new IllegalArgumentException("A connection already exists between these locations.");
        }
        second.neighbours.add(firstKey);
    }

    public void removeConnection(String from, String to) {
        Location first = requireLocation(from);
        Location second = requireLocation(to);
        if (!first.neighbours.remove(key(to))) {
            throw new IllegalArgumentException("No connection exists between these locations.");
        }
        second.neighbours.remove(key(from));
    }

    public Map<String, List<String>> adjacencyList() {
        Map<String, List<String>> result = new LinkedHashMap<>();
        for (Location location : locations.values()) {
            List<String> names = new ArrayList<>();
            for (String neighbour : location.neighbours) {
                names.add(locations.get(neighbour).name);
            }
            result.put(location.name, Collections.unmodifiableList(names));
        }
        return Collections.unmodifiableMap(result);
    }

    /** Visits only vertices reachable from start; each vertex is enqueued once. */
    public List<String> breadthFirstTraversal(String start) {
        requireLocation(start);
        List<String> order = new ArrayList<>();
        Set<String> visited = new LinkedHashSet<>();
        LinkedQueue<String> pending = new LinkedQueue<>();
        visited.add(key(start));
        pending.enqueue(key(start));
        while (!pending.isEmpty()) {
            Location current = locations.get(pending.dequeue());
            order.add(current.name);
            for (String neighbour : current.neighbours) {
                if (visited.add(neighbour)) { pending.enqueue(neighbour); }
            }
        }
        return Collections.unmodifiableList(order);
    }

    public int size() { return locations.size(); }
}
