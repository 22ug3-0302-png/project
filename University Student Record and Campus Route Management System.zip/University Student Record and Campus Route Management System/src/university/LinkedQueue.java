package university;

import java.util.NoSuchElementException;
import java.util.Objects;

/** Custom FIFO queue used for service requests and BFS. */
public final class LinkedQueue<T> {
    private static final class Node<T> {
        private final T value;
        private Node<T> next;
        private Node(T value) { this.value = value; }
    }

    private Node<T> front;
    private Node<T> rear;
    private int size;

    public void enqueue(T value) {
        Node<T> node = new Node<>(Objects.requireNonNull(value));
        if (rear == null) {
            front = node;
        } else {
            rear.next = node;
        }
        rear = node;
        size++;
    }

    public T dequeue() {
        if (isEmpty()) { throw new NoSuchElementException("Queue is empty."); }
        T value = front.value;
        front = front.next;
        if (front == null) { rear = null; }
        size--;
        return value;
    }

    public T peek() {
        if (isEmpty()) { throw new NoSuchElementException("Queue is empty."); }
        return front.value;
    }

    public boolean isEmpty() { return front == null; }
    public int size() { return size; }
}
